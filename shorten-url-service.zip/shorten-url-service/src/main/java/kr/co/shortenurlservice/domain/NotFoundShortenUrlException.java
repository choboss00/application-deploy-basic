package kr.co.shortenurlservice.domain;

public class NotFoundShortenUrlException extends RuntimeException {
}
