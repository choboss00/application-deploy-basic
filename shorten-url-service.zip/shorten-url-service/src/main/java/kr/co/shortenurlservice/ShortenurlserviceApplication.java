package kr.co.shortenurlservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShortenurlserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShortenurlserviceApplication.class, args);
	}

}
